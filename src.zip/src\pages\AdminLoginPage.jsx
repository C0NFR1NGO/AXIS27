import { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { Link, Navigate } from 'react-router-dom';

export default function AdminLoginPage() {
  const { signInWithGoogle, user, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithGoogle();
    } catch (err) {
      setError(err.message || 'Failed to sign in with Google');
    } finally {
      setLoading(false);
    }
  };

  if (user) {
    return <Navigate to={isAdmin ? '/admin' : '/'} replace />;
  }

  return (
    <div style={styles.container}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={styles.card}
      >
        <div style={styles.logoContainer}>
          <img src="/images/logo-icon.webp" alt="AXIS'27" style={styles.logo} />
        </div>
        
        <h1 style={styles.title}>AXIS'27</h1>
        <p style={styles.subtitle}>Login to enter the world of AXIS</p>

        {error && (
          <div style={styles.error}>
            {error}
          </div>
        )}

        <button
          onClick={handleGoogleLogin}
          disabled={loading}
          style={styles.googleButton}
        >
          {loading ? (
            <span style={styles.spinner}></span>
          ) : (
            <>
              <svg style={styles.googleIcon} viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Continue with Google
            </>
          )}
        </button>

        <div style={styles.divider}>
          <span style={styles.dividerLine}></span>
          <span style={styles.dividerText}>SECURE ACCESS</span>
          <span style={styles.dividerLine}></span>
        </div>

        <p style={styles.footer}>
          Login to enter the world of AXIS
        </p>

        <Link to="/" style={styles.backLink}>
          ← Back to AXIS'27
        </Link>
      </motion.div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'radial-gradient(ellipse at 50% 30%, rgba(210,156,56,0.06) 0%, rgba(13,10,8,0.98) 50%, #0d0a08 100%)',
    padding: '2rem',
    position: 'relative',
    overflow: 'hidden',
  },
  card: {
    width: '100%',
    maxWidth: '400px',
    background: 'rgba(12, 10, 8, 0.8)',
    border: '1px solid rgba(229,169,60,0.15)',
    borderRadius: '2px',
    padding: '3rem 2.5rem',
    textAlign: 'center',
    position: 'relative',
    boxShadow: '0 0 60px rgba(229,169,60,0.08), 0 8px 32px rgba(0,0,0,0.4)',
  },
  logoContainer: {
    marginBottom: '2rem',
  },
  logo: {
    width: '80px',
    height: 'auto',
    filter: 'drop-shadow(0 0 20px rgba(0,229,255,0.4)) drop-shadow(0 0 10px rgba(229,169,60,0.3))',
  },
  title: {
    fontFamily: "'Ethnocentric', sans-serif",
    fontSize: '1.8rem',
    fontWeight: 800,
    letterSpacing: '0.15em',
    background: 'linear-gradient(135deg, #fff 0%, var(--gold) 50%, var(--spice-blue) 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    marginBottom: '0.5rem',
    textTransform: 'uppercase',
  },
  subtitle: {
    fontFamily: 'var(--font-mono)',
    fontSize: '0.75rem',
    color: 'var(--text-muted)',
    letterSpacing: '0.1em',
    marginBottom: '2rem',
  },
  error: {
    background: 'rgba(255,51,85,0.1)',
    border: '1px solid rgba(255,51,85,0.3)',
    color: '#ff3555',
    padding: '0.75rem 1rem',
    borderRadius: '2px',
    fontSize: '0.8rem',
    fontFamily: 'var(--font-mono)',
    marginBottom: '1.5rem',
    letterSpacing: '0.05em',
  },
  googleButton: {
    width: '100%',
    padding: '1rem 1.5rem',
    background: '#fff',
    border: 'none',
    borderRadius: '2px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.75rem',
    fontSize: '0.95rem',
    fontWeight: 600,
    color: '#333',
    transition: 'all 0.3s ease',
    boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
  },
  googleIcon: {
    width: '20px',
    height: '20px',
  },
  spinner: {
    width: '20px',
    height: '20px',
    border: '2px solid #ddd',
    borderTopColor: '#333',
    borderRadius: '50%',
    animation: 'spin 0.8s linear infinite',
  },
  divider: {
    display: 'flex',
    alignItems: 'center',
    margin: '2rem 0',
    gap: '1rem',
  },
  dividerLine: {
    flex: 1,
    height: '1px',
    background: 'rgba(229,169,60,0.15)',
  },
  dividerText: {
    fontFamily: 'var(--font-mono)',
    fontSize: '0.6rem',
    color: 'var(--text-muted)',
    letterSpacing: '0.15em',
  },
  footer: {
    fontFamily: 'var(--font-mono)',
    fontSize: '0.65rem',
    color: 'var(--text-muted)',
    letterSpacing: '0.08em',
    opacity: 0.6,
    marginBottom: '1.5rem',
  },
  backLink: {
    fontFamily: 'var(--font-mono)',
    fontSize: '0.7rem',
    color: 'var(--spice-blue)',
    textDecoration: 'none',
    letterSpacing: '0.1em',
    transition: 'color 0.3s',
  },
};

